import styled from "styled-components";

export const StyledCart = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background-color: red;
  border: 0.5px solid gray;
  background-color: rgb(255, 255, 255);
  box-shadow: inset;
  min-height: 300px;
  color:#1f2d42;
  font-weight: bold;

`;
