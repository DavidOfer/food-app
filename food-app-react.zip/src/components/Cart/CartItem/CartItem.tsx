
import { Button } from "@mui/material";
import { useDispatch } from "react-redux";
import { CartItemModel } from "../../../models/CartItemModel";
import { StyledCartItem } from "./CartItem.styled";
import {actionCreators } from '../../../state/index'

interface CartItemProps {
    item: CartItemModel
}

const CartItem: React.FC<CartItemProps> = (props) => {
    const dispatch = useDispatch();
    const addItemHandler = ()=>{
        dispatch(actionCreators.addCartItem(props.item,1));
    }
    const removeItemHandler = ()=>{
        dispatch(actionCreators.removeCartItem(props.item.id,1));
    }
    return (
        <StyledCartItem>
            <div className="dishDetails">
                <div className="dishNameCost">
                    <div className="dishCost">
                        <Button onClick={addItemHandler}>+</Button>
                        {props.item.amount}
                        <Button onClick={removeItemHandler}>-</Button>
                    </div>
                    <div>
                        {props.item.title}
                    </div>
                </div>
                <div>
                    {props.item.totalCost}
                </div>
            </div>
        </StyledCartItem>
    );
}
export default CartItem;