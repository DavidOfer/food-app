import { useTypedSelector } from '../../hooks/useTypedSelector';
import { ResturantContainer } from '../UI/RestaurantContainer/RestaurantContainer'
import { CategoriesLink } from './CategoriesLink/CategoriesLink.styled'

const CategoriesBar: React.FC = () => {
    const Categories = useTypedSelector((state) => {
        return state.shop.data?.foodGroups.map(({ name,id }) => { return {name,id}})
    })
    return (
        <ResturantContainer className="StickyCate">
            {Categories?.map(category =>
                <CategoriesLink key={category.id} offset={-200} activeClass="test" to={`foodGroup${category.id}`} spy={true} smooth={true} duration={300}>
                    {category.name}
                </CategoriesLink>)}
        </ResturantContainer>
    );
}
export default CategoriesBar