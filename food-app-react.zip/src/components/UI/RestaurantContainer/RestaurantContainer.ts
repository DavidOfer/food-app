import styled from "styled-components";

export const ResturantContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 1300px;
  background-color: inherit;
  border: 1px solid;
  
`;
