import { CartAction } from "./cart-actions";
import { ShopAction } from "./shop-actions";

export type Action =
ShopAction | CartAction;
