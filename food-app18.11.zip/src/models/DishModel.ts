export interface DishModel{
    id: number;
    title: string;
    description: string;
    category: string;
    cost: number;
    img:string;
}