//this file is for ALL action types, no need to split
export enum ActionType {
    FETCH_SHOP = 'fetch_shop',
    FETCH_SHOP_SUCCESS = 'fetch_shop_success',
    FETCH_SHOP_ERROR = 'fetch_shop_error',
    ADD_CART_ITEM = 'add_cart_item',
    REMOVE_CART_ITEM ='remove_cart_item'
}