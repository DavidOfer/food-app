export interface CartItemModel{
    id: number;
    title: string;
    amount:number;
    cost: number;
    totalCost:number
    img:string;
}